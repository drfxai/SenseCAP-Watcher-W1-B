# SenseCAP Watcher W1-B — بازیابی فریمور اصلی کارخانه

[وب‌فلشر](https://drfxai.github.io/SenseCAP-Watcher-W1-B/) · [دانلود بسته کامل](https://drfxai.github.io/SenseCAP-Watcher-W1-B/downloads/watcher-factory-1.1.7.zip)

بسته **کلاسیک کارخانه Seeed نسخه 1.1.7** برای سخت‌افزار Watcher با ESP32-S3 و فلش 32 MB. این فریمور Maximus OS یا Watcher Agent / Xiaozhi نیست. باینری‌های اصلی بدون تغییر از [مخزن رسمی Seeed](https://github.com/Seeed-Studio/OSHW-SenseCAP-Watcher/tree/3ca69aefa8441f57d38993a39df714048633d032/Firmware) گرفته شده‌اند. نسخه‌ای که دستگاه شما در روز خرید داشته ممکن است متفاوت باشد. این پروژه ابزار بازیابی مستقل است؛ فایل هویت اختصاصی هیچ دستگاهی را منتشر نمی‌کند.

## نکته تعیین‌کننده برای دستگاه کاملاً پاک‌شده

**نصب فریمور، اطلاعات کارخانه حذف‌شده را تولید نمی‌کند.** پارتیشن `nvsfactory` در آدرس `0x9000` با طول `0x32000` شامل اطلاعات اختصاصی اتصال به SenseCraft است. EUI و شماره‌سریال به‌تنهایی جای آن را نمی‌گیرند. عکس جعبه و EUI برای درخواست کمک از [پشتیبانی Seeed](https://www.seeedstudio.com/contacts) مفیدند؛ امکان بازیابی را باید خود سازنده تأیید کند.

بکاپی که بعد از پاک‌شدن می‌گیرید فقط وضعیت فعلی را ذخیره می‌کند. فایل `nvsfactory.bin` دستگاه دیگری را استفاده نکنید. واردکردن EUI در اپلیکیشن، جای بازنویسی اعتبارنامه‌های کارخانه در فلش را نمی‌گیرد. `factory_info` در فریمور اصلی فرمان نمایش اطلاعات است، نه ساختن هویت.

## چرا KEY روی برچسب برای بازسازی کامل کافی نیست؟

کد رسمی نسخه 1.1.7، اطلاعات کارخانه را از namespace به نام `device_info` می‌خواند و `CODE_SK`، `DEV_KEY_SK` و `AI_KEY_SK` را جداگانه نگهداری می‌کند. KEY چاپ‌شده ۱۶ کاراکتری را نباید بدون تأیید سازنده معادل `DEV_KEY_SK` فرض کرد: تابع اتصال ابری صراحتاً برای device key طول **۳۲ کاراکتر** را الزامی می‌داند. کلید AI هم از فیلد جداگانه خوانده می‌شود. عکس برچسب و صفحه اپلیکیشن می‌تواند EUI، S/N و KEY چاپی را تأیید کند؛ این تصاویر جای دامپ پارتیشن یا کلیدهای حذف‌شده را نمی‌گیرند.

شواهد در کد رسمی همان نسخه:

- [خواندن فیلدهای جداگانه کارخانه](https://github.com/Seeed-Studio/SenseCAP-Watcher-Firmware/blob/95c23160936d9987bbdcc05ffff8dd62b679c5f3/examples/factory_firmware/main/util/factory_info.c)
- [الزام کلید ۳۲ کاراکتری در اتصال SenseCraft](https://github.com/Seeed-Studio/SenseCAP-Watcher-Firmware/blob/95c23160936d9987bbdcc05ffff8dd62b679c5f3/examples/factory_firmware/main/app/app_sensecraft.c#L901-L920)

اطلاعات واقعی یا تصاویر دستگاه خود را در مخزن عمومی commit نکنید. این پروژه هیچ کلیدی را از روی EUI حدس نمی‌زند و پارتیشن هویت ناقص تولید نمی‌کند.

## استفاده از وب‌فلشر

1. صفحه وب‌فلشر را در Chrome یا Edge دسکتاپ باز کنید. HTTPS یا localhost و پشتیبانی Web Serial لازم است.
2. کابل USB-C دیتا را به پورت پایین/کنار دستگاه وصل کنید؛ پورت پشت فقط برق است. مانیتور سریال و برنامه‌های دیگر را ببندید.
3. «اتصال» را بزنید و پورت ESP32 را انتخاب کنید. Watcher دو پورت برای ESP32 و Himax دارد؛ اگر ارتباط برقرار نشد، پورت دیگر را امتحان کنید. ابزار فقط ESP32-S3 با ظرفیت فلش 32 MB را می‌پذیرد؛ این بررسی به‌تنهایی مدل برد را تشخیص نمی‌دهد.
4. بکاپ هویت را دانلود و در محل خصوصی نگهداری کنید. سپس هشدار را تأیید و نصب را شروع کنید. از بسته‌شدن تب، خواب کامپیوتر و قطع کابل جلوگیری کنید.
5. ابزار SHA-256 همه فایل‌ها را پیش از اولین نوشتن بررسی می‌کند، فقط محدوده‌های مشخص را می‌نویسد، نوشته‌ها را با MD5 بررسی می‌کند و تغییرنکردن پارتیشن کارخانه را می‌سنجد. گزینه پاک‌سازی تنظیمات، فقط NVS معمولی را بازنشانی می‌کند.

هیچ فرمان `erase_flash` صادر نمی‌شود. فایل یکپارچه BIN با فاصله‌های پرشده ارائه نمی‌کنیم چون نوشتن آن از آدرس صفر می‌تواند اطلاعات هویتی موجود را پاک کند. ZIP شامل فایل‌های جداگانه و آدرس‌های صحیح است. تنظیمات NVS معمولی به‌طور پیش‌فرض پاک می‌شوند؛ برای حفظ آن‌ها تیک مربوطه را بردارید. داده خارج از محدوده‌های نوشته‌شده لزوماً پاک نمی‌شود.

عملیات پورت و بکاپ در مرورگر انجام می‌شود؛ بکاپ، EUI و اعتبارنامه به سرور ارسال نمی‌شود. اگر اتصال یا نوشتن خطا داد، کابل و انتخاب پورت را بررسی و دوباره متصل شوید. قطع عملیات ممکن است دستگاه را تا فلش موفق بعدی غیرقابل بوت کند.

## فایل‌ها و آدرس‌های رسمی ESP32

| فایل در `public/firmware/esp32/` | آدرس |
| --- | --- |
| `bootloader/bootloader.bin` | `0x0` |
| `partition_table/partition-table.bin` | `0x8000` |
| `ota_data_initial.bin` | `0x10d000` |
| `factory_firmware.bin` | `0x110000` |
| `srmodels/srmodels.bin` | `0x1910000` |
| `storage.bin` | `0x1a10000` |

[manifest و SHA-256 هر فایل](public/firmware/manifest.json) · [SHA256SUMS](public/firmware/SHA256SUMS). شناسه commit منبع: `3ca69aefa8441f57d38993a39df714048633d032`.

## خط فرمان — ویندوز، لینوکس، macOS

ZIP را استخراج کنید و از پوشه اصلی آن اجرا کنید (یا مخزن را clone کنید). Python 3.10+ لازم است. `COM5` را با پورت واقعی ESP32 جایگزین کنید؛ روی لینوکس مثلاً `/dev/ttyACM0` و روی مک `/dev/cu.…` است.

```sh
python -m pip install -r requirements.txt
python tools/verify_firmware.py
python tools/flash.py --port COM5
```

اسکریپت ابتدا بکاپ خصوصی را در `watcher-backups/` ذخیره می‌کند؛ سپس فایل‌ها را جداگانه می‌نویسد و حفظ پارتیشن کارخانه را بررسی می‌کند. برای نگه‌داشتن NVS معمولی، `--keep-settings` اضافه کنید. اگر ارتباط ناپایدار بود `--baud 115200` را امتحان کنید. این ابزار فقط برای Watcher با فلش 32 MB است؛ پیش از اجرای CLI با `python -m esptool --chip esp32s3 --port COM5 flash_id` سخت‌افزار را بررسی کنید.

### بازگرداندن بکاپ واقعی همان دستگاه

فقط اگر بکاپ **پیش از پاک‌کردن** یا فایل معتبر مخصوص دستگاه از سازنده دارید، بعد از نصب بسته اصلی اجرا کنید. نام و پورت نمونه را عوض کنید. محدوده و طول زیر برای همین جدول پارتیشن است؛ فایل نمونه را از اینترنت جایگزین نکنید.

```sh
python -m esptool --chip esp32s3 --port COM5 write_flash 0x9000 YOUR_OWN_nvsfactory.bin
python -m esptool --chip esp32s3 --port COM5 verify_flash 0x9000 YOUR_OWN_nvsfactory.bin
```

بکاپ این پروژه دقیقاً `204800` بایت است. هر فایل با طول یا قالب متفاوت را پیش از نوشتن با پشتیبانی سازنده بررسی کنید. این دستور سریال دلخواه یا EUI جدید تولید نمی‌کند.

## Himax — تراشه جداگانه

[دانلود مستقیم فایل اصلی Himax](https://drfxai.github.io/SenseCAP-Watcher-W1-B/firmware/himax/himax_firmware_20240816.img) · [بخش Himax در صفحه فلشر](https://drfxai.github.io/SenseCAP-Watcher-W1-B/#himax)

نام فایل: `himax_firmware_20240816.img`؛ حجم: `548864` بایت؛ SHA-256: `55ab2bcaee3bf6e0fad149bb06b36139610bb5578847b94c59937eb32875d0fd`.

فلش پاک‌شده ESP32 الزاماً به معنی پاک‌شدن Himax نیست. وب‌فلشر به Himax دست نمی‌زند. فقط اگر آن تراشه نیز نیازمند بازیابی است، [راهنمای رسمی Himax](https://github.com/Seeed-Studio/OSHW-SenseCAP-Watcher/blob/3ca69aefa8441f57d38993a39df714048633d032/Firmware/README.md#for-himax-firmware) را دنبال کنید و پورت دیگر را انتخاب کنید. فایل رسمی در `public/firmware/himax/himax_firmware_20240816.img` قرار دارد. Seeed استفاده از `python-sscma` و دستور `sscma.cli flasher -f firmware.img` را توضیح داده است. پیش از اجرا پورت صحیح را مطابق راهنمای همان ابزار بررسی کنید.

## توسعه و انتشار GitHub Pages

```sh
npm ci
npm test
npm run build
npm run dev
```

برای ساخت ZIP قابل دانلود: `python tools/package_firmware.py` و سپس `npm run build`. برای آزمون مرورگر: `npx playwright install chromium && npm run test:browser`.

Workflow مخزن صحت فایل‌ها، آزمون‌ها و build را اجرا می‌کند و خروجی را در GitHub Pages منتشر می‌کند. تنظیم **Settings → Pages → Build and deployment → Source = GitHub Actions** باید فعال باشد. آدرس نهایی: `https://drfxai.github.io/SenseCAP-Watcher-W1-B/`.

**محدودیت اعتبارسنجی:** صحت فایل‌ها، ساختار پارتیشن، حفاظ‌های نوشتن و جریان مرورگر با دستگاه شبیه‌سازی‌شده بررسی می‌شود. این به معنی تأیید عملی روی دستگاه فیزیکی یا تضمین اتصال SenseCraft پس از حذف اعتبارنامه‌ها نیست.

## مجوز و منبع

کد این پروژه تحت Apache-2.0 است. فایل‌های رسمی Seeed از مخزن دارای [Apache-2.0](LICENSE) با حفظ انتساب و مشخصات منبع بازتوزیع شده‌اند. مجوز وابستگی‌های npm در بسته‌های خودشان موجود است. [منبع SDK کارخانه](https://github.com/Seeed-Studio/SenseCAP-Watcher-Firmware) · [راهنمای رسمی فلش](https://github.com/Seeed-Studio/OSHW-SenseCAP-Watcher/blob/3ca69aefa8441f57d38993a39df714048633d032/Firmware/README.md).
